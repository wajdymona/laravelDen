
<?php $__env->startSection('main'); ?>

<div class="col-sm-12">
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success'), false); ?>  
    </div>
  <?php endif; ?>
</div>
<div class="row">
<div class="col-sm-12">
    <h1 class="display-3">Contacts</h1>   
    <div>
    <a style="margin: 19px;" href="<?php echo e(route('doctor.create'), false); ?>" class="btn btn-primary">New contact</a>
    </div> 
  <table class="table table-striped">
    <thead>
        <tr>
         
          <td>Name</td>
          <td>Email</td>
          <td>Job Title</td>
          <td>City</td>
       
          <td colspan = 2>Actions</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($doctor->f_name, false); ?> <?php echo e($doctor->l_name, false); ?></td>
         
            <td><?php echo e($doctor->age, false); ?></td>
            <td><?php echo e($doctor->phone, false); ?></td>
            <td><?php echo e($doctor->address, false); ?></td>
            <td>
                <a href="<?php echo e(route('doctor.edit',$doctor->id), false); ?>" class="btn btn-primary">Edit</a>
            </td>
            <td>
                <form action="<?php echo e(route('doctor.destroy', $doctor->id), false); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-danger" type="submit">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blo89\resources\views/doctor/index.blade.php ENDPATH**/ ?>

<?php $__env->startSection('main'); ?>


<div class="row">
<div class="col-sm-12">
    <h1 class="display-3">Patients</h1>  
    <div>
    <a style="margin: 19px;" href="/" class="btn btn-primary">home</a>
    </div>  
  <table class="table table-striped">
    <thead>
        <tr>
        
          <td>Patient Name</td>
          
          <td>Age</td>
          <td>Phone</td>
          <td>Address</td>
          <td>Fees</td>
         <td colspan = 2 >Actions</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            
            <td><?php echo e($patient->f_name, false); ?> <?php echo e($patient->l_name, false); ?></td>
            <td><?php echo e($patient->age, false); ?></td>
             <td><?php echo e($patient->phone, false); ?></td>
            <td><?php echo e($patient->address, false); ?></td>
            <td><?php echo e($patient->fees, false); ?></td>
           <td>
                <a href="<?php echo e(route('admin.editP',$patient->id), false); ?>" class="btn btn-primary">Edit</a>
            </td>
            <td>
                <a href="<?php echo e(route('admin.editAP',$patient->id), false); ?>" class="btn btn-primary">add Appointment</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blo89\resources\views/admin/indexP.blade.php ENDPATH**/ ?>
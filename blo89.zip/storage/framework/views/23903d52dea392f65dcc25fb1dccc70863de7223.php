


     
    
<?php $__env->startSection('body'); ?>
    <div class="card card-default">
        <div class="card-header"><?php echo e(isset($post)?"Update Post": "Create Post", false); ?></div>
        <div class="card-body">
            <form action="<?php echo e(isset($post)? route('doctor.update',$post->id):route('doctor.store'), false); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if(isset($post)): ?>
                <?php echo method_field('PUT'); ?>
                <?php endif; ?>
                <div class="form-group">
                    <label for="category"> id</label>
                    <input type="text" name="id"  class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-control" placeholder="Add category name"
                    value="<?php echo e(isset($post)? $post->title :"", false); ?>">
</div>
                <div class="form-group">
                    <label for="category"> Userid</label>
                    <input type="text" name="user-id"  class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-control" placeholder="Add category name"
                    value="<?php echo e(isset($post)? $post->title :"", false); ?>">
</div>
<div class="form-group">
                    <label for="category"> First Name</label>
                    <input type="text" name="f_name"  class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-control" placeholder="Add category name"
                    value="<?php echo e(isset($post)? $post->title :"", false); ?>">
                   
                </div>
                <div class="form-group">
                    <label for="category"> Last Name</label>
                    <input type="text" name="l_name"  class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-control" placeholder="Add category name"
                    value="<?php echo e(isset($post)? $post->title :"", false); ?>">
                   
                </div>
                <div class="form-group">
                    <label for="category"> Age </label>
                    <input type="text" name="age"  class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-control" placeholder="Add category name"
                    value="<?php echo e(isset($post)? $post->title :"", false); ?>">
                   
                </div>
                    <div class="form-group">
                    <label for="category"> Phone </label>
                    <input type="text" name="phone"  class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-control" placeholder="Add category name"
                    value="<?php echo e(isset($post)? $post->title :"", false); ?>">
                   
                </div>
                     <div class="form-group">
                    <label for="category"> Address </label>
                    <input type="text" name="address"  class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-control" placeholder="Add category name"
                    value="<?php echo e(isset($post)? $post->title :"", false); ?>">
                   
                </div>
                     <div class="form-group">
                    <label for="category"> specialty </label>
                    <input type="text" name="specialty"  class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-control" placeholder="Add category name"
                    value="<?php echo e(isset($post)? $post->title :"", false); ?>">
                   
                </div>
                     <div class="form-group">
                    <label for="category"> Experience </label>
                    <input type="text" name="Experience"  class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  form-control" placeholder="Add category name"
                    value="<?php echo e(isset($post)? $post->title :"", false); ?>">
                   
                </div> 

                
<?php if(isset($post)): ?>
<div class="form-group">

    <img src="<?php echo e(asset('storage/'.$post->image), false); ?>" alt="dfs" width="100%"  >

</div>
<?php endif; ?>
                <div class="form-group">
                    <label for="exampleFormControlFile1"> Image </label>
                    <input type="file" class="form-control-file" name="image">
                </div>
                <div class="form-group">
                    <button class="btn btn-success"><?php echo e(isset($post)?"Update":"Add", false); ?></button>
                </div>
            </form>
        </div>
        
           
            
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blo89\resources\views/doctor/create.blade.php ENDPATH**/ ?>
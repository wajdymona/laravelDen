
<?php $__env->startSection('main'); ?>


<div class="row">
<div class="col-sm-12">
  <div>
    <a style="margin: 19px;" href="/" class="btn btn-primary">home</a>
    </div> 
    <h1 class="display-3">Appointments</h1>    
  <table class="table table-striped">
    <thead>
        <tr>
        
          <td>Patient Name</td>
          <td>Doctor Name</td>
          <td>Date</td>
          <td>Time</td>
          <td>Fee</td>
          <td>Diagnosis</td>
          <td>Comleted</td>
         <td >Actions</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            
            <td><?php echo e($appointment->patient->f_name, false); ?> <?php echo e($appointment->patient->l_name, false); ?></td>
            <td><?php echo e($appointment->doctor->f_name, false); ?> <?php echo e($appointment->doctor->l_name, false); ?></td>
            <td><?php echo e($appointment->date, false); ?></td>
             <td><?php echo e($appointment->time, false); ?></td>
            <td><?php echo e($appointment->fee, false); ?></td>
            <td><?php echo e($appointment->diagnosis, false); ?></td>
             <td><?php echo e($appointment->completed, false); ?></td>
           <td>
                <a href="<?php echo e(route('doctor.editA',$appointment->id), false); ?>" class="btn btn-primary">Edit</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blo89\resources\views/doctor/indexA.blade.php ENDPATH**/ ?>
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class doctors extends Model
{
    protected $guarded = ['id'];
}
